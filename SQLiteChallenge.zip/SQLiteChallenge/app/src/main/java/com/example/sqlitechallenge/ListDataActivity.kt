package com.janth.saveanddisplaysql

import android.R
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity
import com.janth.saveanddisplaysql.EditDataActivity
import java.util.*

class ListDataActivity : AppCompatActivity() {
    var mDatabaseHelper: DatabaseHelper? = null
    private var mListView: ListView? = null
    override fun onCreate(@Nullable savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.list_layout)
        mListView = findViewById<View>(R.id.listView) as ListView
        mDatabaseHelper = DatabaseHelper(this)
        populateListView()
    }

    private fun populateListView() {
        Log.d(TAG, "populateListView: Displaying data in the ListView.")

        //get the data and append to a list
        val data: Cursor = mDatabaseHelper.getData()
        val listData = ArrayList<String>()
        while (data.moveToNext()) {
            //get the value from the database in column 1
            //then add it to the ArrayList
            listData.add(data.getString(1))
        }
        //create the list adapter and set the adapter
        val adapter: ListAdapter = ArrayAdapter(this, R.layout.simple_list_item_1, listData)
        mListView!!.adapter = adapter

        //set an onItemClickListener to the ListView
        mListView!!.onItemClickListener = OnItemClickListener { adapterView, view, i, l ->
            val name = adapterView.getItemAtPosition(i).toString()
            Log.d(TAG, "onItemClick: You Clicked on $name")
            val data: Cursor = mDatabaseHelper.getItemID(name) //get the id associated with that name
            var itemID = -1
            while (data.moveToNext()) {
                itemID = data.getInt(0)
            }
            if (itemID > -1) {
                Log.d(TAG, "onItemClick: The ID is: $itemID")
                val editScreenIntent = Intent(this@ListDataActivity, EditDataActivity::class.java)
                editScreenIntent.putExtra("id", itemID)
                editScreenIntent.putExtra("name", name)
                startActivity(editScreenIntent)
            } else {
                toastMessage("No ID associated with that name")
            }
        }
    }

    /**
     * customizable toast
     * @param message
     */
    private fun toastMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val TAG = "ListDataActivity"
    }
}