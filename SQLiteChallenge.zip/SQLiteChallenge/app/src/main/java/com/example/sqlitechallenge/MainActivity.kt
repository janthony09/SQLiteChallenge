package com.janth.saveanddisplaysql

import android.R
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var mDatabaseHelper: DatabaseHelper? = null
    private var btnAdd: Button? = null
    private var btnViewData: Button? = null
    private var editText: EditText? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editText = findViewById<View>(R.id.editText) as EditText
        btnAdd = findViewById<View>(R.id.btnAdd) as Button
        btnViewData = findViewById<View>(R.id.btnView) as Button
        mDatabaseHelper = DatabaseHelper(this)
        btnAdd!!.setOnClickListener {
            val newEntry = editText!!.text.toString()
            if (editText!!.length() != 0) {
                AddData(newEntry)
                editText!!.setText("")
            } else {
                toastMessage("You must put something in the text field!")
            }
        }
        btnViewData!!.setOnClickListener {
            val intent = Intent(this@MainActivity, ListDataActivity::class.java)
            startActivity(intent)
        }
    }

    fun AddData(newEntry: String?) {
        val insertData: Boolean = mDatabaseHelper.addData(newEntry)
        if (insertData) {
            toastMessage("Data Successfully Inserted!")
        } else {
            toastMessage("Something went wrong")
        }
    }

    /**
     * customizable toast
     * @param message
     */
    private fun toastMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}